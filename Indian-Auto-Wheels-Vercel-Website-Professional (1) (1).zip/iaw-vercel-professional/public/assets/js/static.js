document.addEventListener('DOMContentLoaded',()=>{
  const enquiry=document.querySelector('#static-enquiry');
  if(enquiry) enquiry.addEventListener('submit',event=>{
    event.preventDefault();
    const get=name=>enquiry.elements[name]?.value||'Not specified';
    const message=['Hello Indian Auto Wheels,','',`Name: ${get('name')}`,`Mobile: ${get('mobile')}`,`Email: ${get('email')}`,`City / District: ${get('city')}`,`Requirement: ${get('requirement')}`,`Vehicle / Product: ${get('product')}`,`Message: ${get('message')}`].join('\n');
    window.open(`https://wa.me/${enquiry.dataset.whatsapp}?text=${encodeURIComponent(message)}`,'_blank','noopener');
  });
  const career=document.querySelector('#career-static-form');
  if(career) career.addEventListener('submit',event=>{
    event.preventDefault();
    const get=name=>career.elements[name]?.value||'Not specified';
    const message=['Hello Indian Auto Wheels HR,','',`Name: ${get('name')}`,`Mobile: ${get('mobile')}`,`Position: ${get('position')}`,`Preferred Location: ${get('location')}`,`Experience: ${get('experience')}`,`Message: ${get('message')}`].join('\n');
    window.open(`https://wa.me/${career.dataset.whatsapp}?text=${encodeURIComponent(message)}`,'_blank','noopener');
  });
});

